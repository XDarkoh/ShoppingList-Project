package Shopping;

public class EmptyCollectionException extends Exception {
    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public EmptyCollectionException(String message) {
        super(message);
    }
}
